public interface Output {
    void write(Object o);
    void writeString(String s);
}

