#!/bin/bash
g++ -std=c++11 $1 -o thinghoyoung testVector.cpp vector.cpp
./thinghoyoung