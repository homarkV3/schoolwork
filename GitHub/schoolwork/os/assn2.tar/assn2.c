#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
pid_t pid;
	pid = fork();
	if (pid < 0){
		fprintf(stderr, "Fork Failed");
		return 1;
	}
	else if (pid == 0){
		printf("Child started. ");
		if (argc < 2){
			printf("No arguments provided. Terminatring child.\n");
		}
		else if (argc < 4){
			printf("More then one argument provided. Calling execvp(), never to return (sniff)\n");
			execvp(argv[1], argv + 1);
		}
	}
	else{
		printf("PARENT started now waiting for process ID#%d\n", pid);
		wait(NULL);
		printf("PARENT resumed. Child exit code of 0. Now terminating parent\n");
	}
	return 0;
}
